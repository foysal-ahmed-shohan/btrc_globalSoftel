
<?php $__env->startSection('content'); ?>
<section class="container">
    <div class="user-box p-3 mt-4">
        <h3 class="text-dark">File Download Activity List</h3>
        <div class="under-line bg-black mb-3"></div>

        <div class="overflow-auto">
            <table id="myTable" class="text-dark table">
                <thead class="bg-white text-dark">
                <tr>
                    <th>Sl.</th>
                    <th>User Type</th>
                    <th>Name</th>
                    <th>E-mail</th>
                    <th>File Name</th>
                    <th>Date</th>
                    <th>Time</th>

                </tr>
                </thead>
                <tbody>
                <?php $key=1; ?>
                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key++); ?></td>
                    <td><?php if($value->is_admin==1): ?>Admin <?php else: ?> User <?php endif; ?></td>
                    <td><?php echo e($value->name); ?></td>
                    <td><?php echo e($value->email); ?></td>
                    <td><?php echo e($value->file_original_name_with_extension); ?></td>
                    <td><?php echo e($value->date); ?></td>
                    <td><?php echo e($value->time); ?></td>






                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\project\btrc_globalSoftel\resources\views/admin/downloadActivity/list.blade.php ENDPATH**/ ?>