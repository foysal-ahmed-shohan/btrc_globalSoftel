<?php

namespace App\Http\Controllers\User;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Apply;
use App\Models\User;
use App\Models\File;
use Auth;

class FileController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      $user=File::where('user_id',Auth::id())->first();
      return view('customer.file.create',compact('user'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //return $request;

    $user_info =User::where('id',Auth::id())->first();
    $driving_licence_social_security= $request->file('driving_licence_social_security');
    if ($driving_licence_social_security != '')
    {
        $value=1;
        foreach($driving_licence_social_security as $file)
        {
            $driving_licence_social_security ='driving_licence_social_security_'.$value.'.'.$file->extension();
            $file->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $driving_licence_social_security);
            $data[] = $driving_licence_social_security;
            $value++;
        }
      if($file=File::where('user_id',Auth::id())->first()){
        $file->driving_licence_social_security=json_encode($data);
        $file->save();
       }
    }

      $two_years_tax_returns_w2= $request->file('two_years_tax_returns_w2');
    if ($two_years_tax_returns_w2 != '')
    {
        $two_years_tax_returns_w2 = 'two_years_tax_returns_w2_2'.time().'.'.$request->two_years_tax_returns_w2->extension();
        $request->two_years_tax_returns_w2->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $two_years_tax_returns_w2);

        if($file=File::where('user_id',Auth::id())->first()){
        $file->two_years_tax_returns_w2=$two_years_tax_returns_w2;
        $file->save();
       }
    }


      $thirty_days_paystubs= $request->file('thirty_days_paystubs');
    if ($thirty_days_paystubs != '')
    {
        $thirty_days_paystubs = 'thirty_days_paystubs_3'.time().'.'.$request->thirty_days_paystubs->extension();
        $request->thirty_days_paystubs->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $thirty_days_paystubs);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->thirty_days_paystubs=$thirty_days_paystubs;
        $file->save();
       }
    }


      $two_months_bank_statements_all= $request->file('two_months_bank_statements_all');
    if ($two_months_bank_statements_all != '')
    {
        $two_months_bank_statements_all = 'two_months_bank_statements_all_4'.time().'.'.$request->two_months_bank_statements_all->extension();
        $request->two_months_bank_statements_all->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $two_months_bank_statements_all);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->two_months_bank_statements_all=$two_months_bank_statements_all;
        $file->save();
       }
    }



      $work_permit_greencard_passport_6month= $request->file('work_permit_greencard_passport_6month');
    if ($work_permit_greencard_passport_6month != '')
    {
        $work_permit_greencard_passport_6month = 'work_permit_greencard_passport_6month_5'.time().'.'.$request->work_permit_greencard_passport_6month->extension();
        $request->work_permit_greencard_passport_6month->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $work_permit_greencard_passport_6month);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->work_permit_greencard_passport_6month=$work_permit_greencard_passport_6month;
        $file->save();
       }
    }



      $ratified_sales_contract= $request->file('ratified_sales_contract');
    if ($ratified_sales_contract != '')
    {
        $ratified_sales_contract = 'ratified_sales_contract_6'.time().'.'.$request->ratified_sales_contract->extension();
        $request->ratified_sales_contract->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $ratified_sales_contract);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->ratified_sales_contract=$ratified_sales_contract;
        $file->save();
       }
    }



      $stocks_bonds= $request->file('stocks_bonds');
    if ($stocks_bonds != '')
    {
        $stocks_bonds = 'stocks_bonds_7'.time().'.'.$request->stocks_bonds->extension();
        $request->stocks_bonds->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $stocks_bonds);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->stocks_bonds=$stocks_bonds;
        $file->save();
       }
    }


      $hazard_insurance_quote= $request->file('hazard_insurance_quote');
    if ($hazard_insurance_quote != '')
    {
        $hazard_insurance_quote = 'hazard_insurance_quote_8'.time().'.'.$request->hazard_insurance_quote->extension();
        $request->hazard_insurance_quote->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $hazard_insurance_quote);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->hazard_insurance_quote=$hazard_insurance_quote;
        $file->save();
       }
    }


      $recent_mortgage_statement= $request->file('recent_mortgage_statement');
    if ($recent_mortgage_statement != '')
    {
        $recent_mortgage_statement = 'recent_mortgage_statement_9'.time().'.'.$request->recent_mortgage_statement->extension();
        $request->recent_mortgage_statement->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $recent_mortgage_statement);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->recent_mortgage_statement=$recent_mortgage_statement;
        $file->save();
       }
    }


      $court_order_child_support= $request->file('court_order_child_support');
    if ($court_order_child_support != '')
    {
        $court_order_child_support = 'court_order_child_support-10'.time().'.'.$request->court_order_child_support->extension();
        $request->court_order_child_support->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $court_order_child_support);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->court_order_child_support=$court_order_child_support;
        $file->save();
       }
    }


      $ytd_profit_loss_statement= $request->file('ytd_profit_loss_statement');
    if ($ytd_profit_loss_statement != '')
    {
        $ytd_profit_loss_statement = 'ytd_profit_loss_statement_11'.time().'.'.$request->ytd_profit_loss_statement->extension();
        $request->ytd_profit_loss_statement->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $ytd_profit_loss_statement);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->ytd_profit_loss_statement=$ytd_profit_loss_statement;
        $file->save();
       }
    }


      $twelve_month_bank_statement= $request->file('twelve_month_bank_statement');
    if ($twelve_month_bank_statement != '')
    {
        $twelve_month_bank_statement = 'twelve_month_bank_statement_12'.time().'.'.$request->twelve_month_bank_statement->extension();
        $request->twelve_month_bank_statement->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $twelve_month_bank_statement);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->twelve_month_bank_statement=$twelve_month_bank_statement;
        $file->save();
       }
    }


      $utility_bills= $request->file('utility_bills');
    if ($utility_bills != '')
    {
        $utility_bills = 'utility_bills_13'.time().'.'.$request->utility_bills->extension();
        $request->utility_bills->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $utility_bills);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->utility_bills=$utility_bills;
        $file->save();
       }
    }


      $original_promissory_note= $request->file('original_promissory_note');
    if ($original_promissory_note != '')
    {
        $original_promissory_note = 'original_promissory_note_14'.time().'.'.$request->original_promissory_note->extension();
        $request->original_promissory_note->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $original_promissory_note);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->original_promissory_note=$original_promissory_note;
        $file->save();
       }
    }


      $driving_license= $request->file('driving_license');
    if ($driving_license != '')
    {
        $driving_license = 'driving_license_15'.time().'.'.$request->driving_license->extension();
        $request->driving_license->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $driving_license);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->driving_license=$driving_license;
        $file->save();
       }
    }


      $signed_federal_tax= $request->file('signed_federal_tax');
    if ($signed_federal_tax != '')
    {
        $signed_federal_tax = 'signed_federal_tax_16'.time().'.'.$request->signed_federal_tax->extension();
        $request->signed_federal_tax->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $signed_federal_tax);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->signed_federal_tax=$signed_federal_tax;
        $file->save();
       }
    }



      $thirty_days_paystubs_all_jobs= $request->file('thirty_days_paystubs_all_jobs');
    if ($thirty_days_paystubs_all_jobs != '')
    {
        $thirty_days_paystubs_all_jobs = 'thirty_days_paystubs_all_jobs_17'.time().'.'.$request->thirty_days_paystubs_all_jobs->extension();
        $request->thirty_days_paystubs_all_jobs->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $thirty_days_paystubs_all_jobs);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->thirty_days_paystubs_all_jobs=$thirty_days_paystubs_all_jobs;
        $file->save();
       }
    }


      $ss_benefits_child_support= $request->file('ss_benefits_child_support');
    if ($ss_benefits_child_support != '')
    {
        $ss_benefits_child_support = 'ss_benefits_child_support_18'.time().'.'.$request->ss_benefits_child_support->extension();
        $request->ss_benefits_child_support->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $ss_benefits_child_support);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->ss_benefits_child_support=$ss_benefits_child_support;
        $file->save();
       }
    }


      $DD_214_va_eligibility= $request->file('DD_214_va_eligibility');
    if ($DD_214_va_eligibility != '')
    {
        $DD_214_va_eligibility = 'DD_214_va_eligibility_19'.time().'.'.$request->DD_214_va_eligibility->extension();
        $request->DD_214_va_eligibility->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $DD_214_va_eligibility);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->DD_214_va_eligibility=$DD_214_va_eligibility;
        $file->save();
       }
    }


      $divorce_decree= $request->file('divorce_decree');
    if ($divorce_decree != '')
    {
        $divorce_decree = 'divorce_decree_20'.time().'.'.$request->divorce_decree->extension();
        $request->divorce_decree->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $divorce_decree);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->divorce_decree=$divorce_decree;
        $file->save();
       }
    }


      $bank_statements_all_pages_accounts= $request->file('bank_statements_all_pages_accounts');
    if ($bank_statements_all_pages_accounts != '')
    {
        $bank_statements_all_pages_accounts = 'bank_statements_all_pages_accounts_21'.time().'.'.$request->bank_statements_all_pages_accounts->extension();
        $request->bank_statements_all_pages_accounts->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $bank_statements_all_pages_accounts);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->bank_statements_all_pages_accounts=$bank_statements_all_pages_accounts;
        $file->save();
       }
    }


      $stock_bonds_401k_statements= $request->file('stock_bonds_401k_statements');
    if ($stock_bonds_401k_statements != '')
    {
        $stock_bonds_401k_statements = 'stock_bonds_401k_statements_22'.time().'.'.$request->stock_bonds_401k_statements->extension();
        $request->stock_bonds_401k_statements->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $stock_bonds_401k_statements);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->stock_bonds_401k_statements=$stock_bonds_401k_statements;
        $file->save();
       }
    }


      $gift_certificate_donor_bank= $request->file('gift_certificate_donor_bank');
    if ($gift_certificate_donor_bank != '')
    {
        $gift_certificate_donor_bank = 'gift_certificate_donor_bank_23'.time().'.'.$request->gift_certificate_donor_bank->extension();
        $request->gift_certificate_donor_bank->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $gift_certificate_donor_bank);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->gift_certificate_donor_bank=$gift_certificate_donor_bank;
        $file->save();
       }
    }


      $bankruptcy_discharged_court_order= $request->file('bankruptcy_discharged_court_order');
    if ($bankruptcy_discharged_court_order != '')
    {
        $bankruptcy_discharged_court_order = 'bankruptcy_discharged_court_order_24'.time().'.'.$request->bankruptcy_discharged_court_order->extension();
        $request->bankruptcy_discharged_court_order->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $bankruptcy_discharged_court_order);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->bankruptcy_discharged_court_order=$bankruptcy_discharged_court_order;
        $file->save();
       }
    }


      $ratified_sales_contract_addendums= $request->file('ratified_sales_contract_addendums');
    if ($ratified_sales_contract_addendums != '')
    {
        $ratified_sales_contract_addendums = 'ratified_sales_contract_addendums_25'.time().'.'.$request->ratified_sales_contract_addendums->extension();
        $request->ratified_sales_contract_addendums->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $ratified_sales_contract_addendums);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->ratified_sales_contract_addendums=$ratified_sales_contract_addendums;
        $file->save();
       }
    }


      $credit_card_statements= $request->file('credit_card_statements');
    if ($credit_card_statements != '')
    {
        $credit_card_statements = 'credit_card_statements_26'.time().'.'.$request->credit_card_statements->extension();
        $request->credit_card_statements->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $credit_card_statements);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->credit_card_statements=$credit_card_statements;
        $file->save();
       }
    }


      $mortgage_statement_refinance_investment= $request->file('mortgage_statement_refinance_investment');
    if ($mortgage_statement_refinance_investment != '')
    {
        $mortgage_statement_refinance_investment = 'mortgage_statement_refinance_investment_27'.time().'.'.$request->mortgage_statement_refinance_investment->extension();
        $request->mortgage_statement_refinance_investment->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $mortgage_statement_refinance_investment);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->mortgage_statement_refinance_investment=$mortgage_statement_refinance_investment;
        $file->save();
       }
    }


      $home_insurance_agent_contact= $request->file('home_insurance_agent_contact');
    if ($home_insurance_agent_contact != '')
    {
        $home_insurance_agent_contact = 'home_insurance_agent_contact_28'.time().'.'.$request->home_insurance_agent_contact->extension();
        $request->home_insurance_agent_contact->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $home_insurance_agent_contact);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->home_insurance_agent_contact=$home_insurance_agent_contact;
        $file->save();
       }
    }


      $cleared_emd_check= $request->file('cleared_emd_check');
    if ($cleared_emd_check != '')
    {
        $cleared_emd_check = 'cleared_emd_check_29'.time().'.'.$request->cleared_emd_check->extension();
        $request->cleared_emd_check->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $cleared_emd_check);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->cleared_emd_check=$cleared_emd_check;
        $file->save();
       }
    }


      $copy_lease_rental= $request->file('copy_lease_rental');
    if ($copy_lease_rental != '')
    {
        $copy_lease_rental = 'copy_lease_rental_30'.time().'.'.$request->copy_lease_rental->extension();
        $request->copy_lease_rental->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $copy_lease_rental);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->copy_lease_rental=$copy_lease_rental;
        $file->save();
       }
    }


      $additional_paperwork_one= $request->file('additional_paperwork_one');
    if ($additional_paperwork_one != '')
    {
        $additional_paperwork_one = 'additional_paperwork_one_31'.time().'.'.$request->additional_paperwork_one->extension();
        $request->additional_paperwork_one->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $additional_paperwork_one);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->additional_paperwork_one=$additional_paperwork_one;
        $file->save();
       }
    }


      $additional_paperwork_two= $request->file('additional_paperwork_two');
    if ($additional_paperwork_two != '')
    {
        $additional_paperwork_two = 'additional_paperwork_two_32'.time().'.'.$request->additional_paperwork_two->extension();
        $request->additional_paperwork_two->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $additional_paperwork_two);

         if($file=File::where('user_id',Auth::id())->first()){
        $file->additional_paperwork_two=$additional_paperwork_two;
        $file->save();
       }
    }


      $additional_paperwork_three= $request->file('additional_paperwork_three');
    if ($additional_paperwork_three != '')
    {
        $additional_paperwork_three = 'additional_paperwork_three_33'.time().'.'.$request->additional_paperwork_three->extension();
        $request->additional_paperwork_three->move(public_path('/userFile/'.$user_info->id.'_'.$user_info->email), $additional_paperwork_three);

        if($file=File::where('user_id',Auth::id())->first()){
        $file->additional_paperwork_three=$additional_paperwork_three;
        $file->save();
       }
    }
    toastr()->success('Success');
    return back();

      // $form_data = array(
      //       'user_id'=> Auth::id(),
      //       'driving_licence_social_security'=>$driving_licence_social_security,
      //       'two_years_tax_returns_w2'=>$two_years_tax_returns_w2,
      //       'thirty_days_paystubs'=>$thirty_days_paystubs,
      //       'two_months_bank_statements_all'=>$two_months_bank_statements_all,
      //       'work_permit_greencard_passport_6month'=>$work_permit_greencard_passport_6month,
      //       'ratified_sales_contract'=>$ratified_sales_contract,
      //       'stocks_bonds'=>$stocks_bonds,
      //       'hazard_insurance_quote'=>$hazard_insurance_quote,
      //       'recent_mortgage_statement'=>$recent_mortgage_statement,
      //       'court_order_child_support'=>$court_order_child_support,
      //       'ytd_profit_loss_statement'=>$ytd_profit_loss_statement,
      //        'twelve_month_bank_statement'=>$twelve_month_bank_statement,
      //       'utility_bills'=>$utility_bills,
      //       'original_promissory_note'=>$original_promissory_note,
      //       'driving_license'=>$driving_license,
      //       'signed_federal_tax'=>$signed_federal_tax,
      //       'thirty_days_paystubs_all_jobs'=>$thirty_days_paystubs_all_jobs,
      //       'ss_benefits_child_support'=>$ss_benefits_child_support,
      //       'DD_214_va_eligibility'=>$DD_214_va_eligibility,
      //       'divorce_decree'=>$divorce_decree,
      //       'bank_statements_all_pages_accounts'=>$bank_statements_all_pages_accounts,
      //       'stock_bonds_401k_statements'=>$stock_bonds_401k_statements,
      //       'gift_certificate_donor_bank'=>$gift_certificate_donor_bank,
      //       'bankruptcy_discharged_court_order'=>$bankruptcy_discharged_court_order,
      //       'ratified_sales_contract_addendums'=>$ratified_sales_contract_addendums,
      //       'credit_card_statements'=>$credit_card_statements,
      //       'mortgage_statement_refinance_investment'=>$mortgage_statement_refinance_investment,
      //       'home_insurance_agent_contact'=>$home_insurance_agent_contact,
      //       'cleared_emd_check'=>$cleared_emd_check,
      //       'copy_lease_rental'=>$copy_lease_rental,
      //       'additional_paperwork_one'=>$additional_paperwork_one,
      //       'additional_paperwork_two'=>$additional_paperwork_two,
      //       'additional_paperwork_three'=>$additional_paperwork_three
      //       );
      //   File::create($form_data);


   }


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
